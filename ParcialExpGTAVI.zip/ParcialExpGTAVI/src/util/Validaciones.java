/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/**
 *
 * @author tob
 */
public class Validaciones {
    
    private Validaciones(){
    }
    
    public static void validarTextoNoVacio(String texto, String mensaje){
        if (texto == null || texto.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    public static void validarEnteroPositivo(int valor, String mensaje){
        if (valor <= 0){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    public static void validarNoNegativo(int valor, String mensaje){
        if (valor < 0){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    
}
