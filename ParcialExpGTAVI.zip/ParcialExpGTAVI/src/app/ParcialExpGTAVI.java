/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package app;

import config.AppConfig;
import exceptions.ElementoDuplicadoException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import model.EstadoPublicacion;
import model.Publicacion;
import model.TipoPublicacion;
import persistence.PlataformaViral;
import service.ServicioPublicaciones;

public class Principal {

    public static void main(String[] args) {

        try {
            PlataformaViral<Publicacion> plataforma = new PlataformaViral<>();

            List<Publicacion> publicacionesDemo = new ArrayList<>();

            ServicioPublicaciones.cargarPublicacionesDePrueba(publicacionesDemo);

            plataforma.agregarTodos(publicacionesDemo);

            System.out.println("PUBLICACIONES CARGADAS:");

            for (Publicacion p : plataforma) {
                System.out.println(p);
            }

    

            System.out.println("\nPUBLICACIONES ACTIVAS:");

            plataforma.filtrar(p -> p.getEstado() == EstadoPublicacion.ACTIVA)
                    .forEach(p -> System.out.println(p));


            System.out.println("\nPUBLICACIONES VIRALES:");

            plataforma.filtrar(p -> p.getReproducciones() >= 20000 && p.getInteraccion() >= 15)
                    .forEach(p -> System.out.println(p));


            System.out.println("\nCONTENIDOS DE ENTRETENIMIENTO:");

            plataforma.filtrar(p -> (p.getTipo() == TipoPublicacion.HUMOR
                    || p.getTipo() == TipoPublicacion.ANIMALES)
                    && p.getEstado() != EstadoPublicacion.DENUNCIADA)
                    .forEach(p -> System.out.println(p));

        

            int bajaPopularidad = plataforma.contar(p -> p.getReproducciones() < 10000
                    || p.getInteraccion() < 10);

            System.out.println("Publicaciones con baja popularidad: "
                    + bajaPopularidad);

 

            int monetizadas = plataforma.actualizar(
                    p -> p.getEstado() == EstadoPublicacion.ACTIVA
                            && p.getReproducciones() >= 20000
                            && p.getInteraccion() >= 15,
                    p -> p.setEstado(EstadoPublicacion.MONETIZADA)
            );

            System.out.println("Publicaciones monetizadas: "
                    + monetizadas);

 

            int promocionadas = plataforma.actualizar(
                    p -> p.getEstado() == EstadoPublicacion.MONETIZADA,
                    p -> {
                        p.setReproducciones(p.getReproducciones() + 5000);
                        p.setLikes(p.getLikes() + 1000);
                    }
            );

            System.out.println("Publicaciones promocionadas: " + promocionadas);

          
            List<String> titulos
                    = plataforma.seleccionarYTransformar(
                            p -> p.getEstado() == EstadoPublicacion.MONETIZADA,
                            p -> p.getTitulo()
                    );

            titulos.forEach(t -> System.out.println(t));

        
            List<Double> interacciones
                    = plataforma.seleccionarYTransformar(
                            p -> p.getEstado() != EstadoPublicacion.DENUNCIADA,
                            p -> p.getInteraccion()
                    );

            interacciones.forEach(i -> System.out.println(i));

      

            double promedioReproducciones
                    = plataforma.promediar(
                            p -> p.getEstado() == EstadoPublicacion.MONETIZADA,
                            p -> p.getReproducciones()
                    );

            System.out.println("Promedio de reproducciones: " + promedioReproducciones);



            double ingresoPromedio = plataforma.promediar(
                    p -> p.getEstado() == EstadoPublicacion.MONETIZADA,
                    p -> p.getReproducciones() * 0.02 + p.getLikes() * 0.05
            );

            System.out.println("Ingreso publicitario promedio: $"
                    + ingresoPromedio);

         

            System.out.println("\nPUBLICACIONES ORDENADAS POR ID:");

            plataforma.ordenar();

            plataforma.forEach(p -> System.out.println(p));

            

            System.out.println("\nRANKING DE POPULARIDAD:");

            plataforma.ordenar((a, b) -> Double.compare(b.getInteraccion(), a.getInteraccion()));

            plataforma.forEach(p -> System.out.println(p));

           

            System.out.println("\nPUBLICACIONES POR AUTOR:");

            plataforma.ordenar((a, b) -> {
                int resultado = a.getAutor().compareToIgnoreCase(b.getAutor());
                if (resultado == 0) {
                    resultado = Integer.compare(b.getReproducciones(), a.getReproducciones());
                }
                return resultado;
            });

            plataforma.forEach(p -> System.out.println(p));

      

            plataforma.exportarReporte(
                    AppConfig.ARCHIVO_TXT,
                    AppConfig.TITULO_REPORTE,
                    p -> p.getEstado() == EstadoPublicacion.MONETIZADA && p.getInteraccion() >= 15,
                    p -> String.format(Locale.US, "[%d] %s - @%s - %.1f%%",
                            p.getId(), p.getTitulo(), p.getAutor(), p.getInteraccion())
            );

            plataforma.guardarBinario(AppConfig.ARCHIVO_BINARIO);

            PlataformaViral<Publicacion> recuperadaBinario = new PlataformaViral<>();

            recuperadaBinario.cargarBinario(AppConfig.ARCHIVO_BINARIO);

            System.out.println("\nPUBLICACIONES DESDE BINARIO:");

            recuperadaBinario.forEach(p -> System.out.println(p));

            // 16. Persistencia CSV

            plataforma.guardarCSV(
                    AppConfig.ARCHIVO_CSV,
                    Publicacion.getCSVHeader());

            PlataformaViral<Publicacion> recuperadaCSV
                    = new PlataformaViral<>();

            recuperadaCSV.cargarCSV(
                    AppConfig.ARCHIVO_CSV,
                    linea -> Publicacion.fromCSV(linea)
            );

            System.out.println("\nPUBLICACIONES DESDE CSV:");

            recuperadaCSV.forEach(p -> System.out.println(p));



            int eliminadas = plataforma.eliminarSi(p -> p.getEstado() == EstadoPublicacion.DENUNCIADA);

            System.out.println("Publicaciones eliminadas: " + eliminadas);

            System.out.println("Publicaciones restantes: " + plataforma.cantidad());

            ServicioPublicaciones.mostrarPublicaciones(plataforma.obtenerTodos());



            List<Object> destinoGenerico = new ArrayList<>();

            ServicioPublicaciones.cargarPublicacionesDePrueba(destinoGenerico);

        } catch (IOException | ClassNotFoundException e) {

            System.err.println("Error de archivo: "
                    + e.getMessage());

        } catch (ElementoDuplicadoException e) {

            System.err.println(e.getMessage());
        }
    }
}
