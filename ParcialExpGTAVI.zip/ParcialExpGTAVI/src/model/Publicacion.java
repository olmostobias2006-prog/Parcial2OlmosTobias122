/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.Objects;
import util.CSVSerializable;
import util.Validaciones;
/**
 *
 * @author tob
 */
public class Publicacion implements Comparable<Publicacion>, Serializable, CSVSerializable {
    
    private static final String CSV_HEADER = "id, titulo, autor, reproducciones, likes, tipo, estado";
    private final int id;
    private String titulo;
    private String autor;
    private int reproducciones;
    private int likes;
    private tipoPublicacion tipo;
    private estadoPublicacion estado;
    
    public Publicacion(int id, String titulo, String autor, int reproducciones, int likes, tipoPublicacion tipo, estadoPublicacion estado){
        Validaciones.validarEnteroPositivo(id, "El id debe ser mayor que cero");
        Validaciones.validarTextoNoVacio(titulo, "El titulo no puede estar en blanco");
        Validaciones.validarTextoNoVacio(autor, "El autor no puede estar en blanco");
        Validaciones.validarNoNegativo(reproducciones, "Las reproducciones no pueden ser negativas");
        Validaciones.validarNoNegativo(likes, "Los likes no pueden ser negativos");
        Objects.requireNonNull(tipo, "El tipo no puede estar en blanco");
        Objects.requireNonNull(estado, "El estado no puede estar en blanco");
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.reproducciones = reproducciones;
        this.likes = likes;
        this.tipo = tipo;
        this.estado = estado;       
        }
    
    public int getId(){
        return id;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public void setTitulo(String titulo){
        Validaciones.validarTextoNoVacio(titulo, "El titulo no puede estar en blanco");
        this.titulo = titulo;
    }
    
    public String getAutor(){
        return autor;
    }
    
    public void setAutor(String autor){
        Validaciones.validarTextoNoVacio(autor, "El autor no puede estar en blanco");
        this.autor = autor;
    }
    
    public int getReproducciones(){
        return reproducciones;
    }
    
    public void setReproducciones(int reproducciones){
        Validaciones.validarNoNegativo(reproducciones, "Las reproducciones no pueden ser negativas");
        this.reproducciones = reproducciones;
    }
    
    public int getLikes(){
        return likes;
    }
    
    public void setLikes(int likes){
        Validaciones.validarNoNegativo(likes, "Los likes no pueden ser negativos");
        this.likes = likes;
    }
    
    public tipoPublicacion getTipo(){
        return tipo;
    }
    
    public void setTipo(tipoPublicacion tipo){
        Objects.requireNonNull(tipo, "El tipo no puede estar en blanco");
        this.tipo = tipo;
    }
    
    public estadoPublicacion getEstado(){
        return estado;
    }
    
    public void setEstado(estadoPublicacion estado){
        Objects.requireNonNull(estado, "El estado no puede estar en blanco");
        this.estado = estado;
    }
    
    public double getInteraccion(){
        if (reproducciones == 0){
            return 0;
        }
        return likes * 100.0 / reproducciones;
    }
    
    public static String getCSVHeader(){
        return CSV_HEADER;
    }
    
    @Override
    public String toCSV(){
        return id + "," + titulo + "," + autor + "," + reproducciones + "," + likes + "," + tipo + "," + estado;
    }
    
    public static Publicacion fromCSV(String linea){
        Objects.requireNonNull(linea, "La linea CSV no puede ser nula");
        String[] partes = linea.split(",");
        if (partes.length != 7){
            throw new IllegalArgumentException("Linea CSV invalida");
        }
        int id = Integer.parseInt(partes[0].trim());
        String titulo = partes[1].trim();
        String autor = partes[2].trim();
        int reproducciones = Integer.parseInt(partes[3].trim());
        int likes = Integer.parseInt(partes[4].trim());
        tipoPublicacion tipo = tipoPublicacion.valueOf(partes[5].trim());
        estadoPublicacion estado = estadoPublicacion.valueOf(partes[5].trim());
        return new Publicacion(id, titulo, autor, reproducciones, likes, tipo, estado);
    }
    
    @Override
    public int compareTo(Publicacion otra){
        return Integer.compare(this.id, otra.id);
    }
    
    @Override
    public boolean equals(Object obj){
        return this == obj || (obj instanceof Publicacion otra && id == otra.id);
    }
    
    @Override
    public int hashCode(){
        return Integer.hashCode(id);
    }
    
    @Override
    public String toString(){
        return "Publicaciones{id=" + id + ", titulo=" + titulo + ", autor=" + autor + ", reproducciones=" + reproducciones + ", likes" + likes + ", tipo="
                + tipo + ", estado=" + estado + "}";
    }
    
    
}