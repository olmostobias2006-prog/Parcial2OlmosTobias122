/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

/**
 *
 * @author tob
 */
public class AppConfig {
    
    String PATH_DATA = "src/data/";
    String ARCHIVO_BINARIO = PATH_DATA + "publicaciones.bin";
    String ARCHIVO_CSV = PATH_DATA + "publicaciones.csv";
    String ARCHIVO_TXT = PATH_DATA + "reporte.txt";
    String TITULO_REPORTE = "PUBLICACIONES VIRALES MONETIZADAS";
    
}
