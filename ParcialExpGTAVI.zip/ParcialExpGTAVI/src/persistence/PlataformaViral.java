/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistence;

import exceptions.ElementoDuplicadoException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import util.CSVSerializable;
import util.Calculador;
/**
 *
 * @author tob
 */
public class PlataformaViral<T extends CSVSerializable & Serializable & Comparable<T>> implements Administrable<T>, Persistible<T>, Iterable<T> {
    private List<T> elementos;
    
    public PlataformaViral(){
        elementos = new ArrayList<>();
    }
    
    @Override
    public void agregar(T elemento){
        agregarEn(elementos, elemento);
    }
    
    private void agregarEn(List<T> destino, T elemento){
        Objects.requireNonNull(elemento, "El elemento no puede ser nulo");
        if (destino.contains(elemento)){
            throw new ElementoDuplicadoException("Ya existe un elemento igual: " + elemento);
        }
        destino.add(elemento);
    }
    
    @Override
    public void agregarTodos(List<? extends T> nuevos){
        Objects.requireNonNull(nuevos, "La lista no puede ser nula");
        for (T elemento : nuevos){
            agregar(elemento);
        }
    }
    
    @Override
    public int cantidad(){
        return elementos.size();
    }
    
    @Override
    public List<T> filtrar(Predicate<? super T> criterio){
        Objects.requireNonNull(criterio,"El criterio no puede ser nulo");
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos){
            if (criterio.test(elemento)){
                resultado.add(elemento);
            }
        }
        return resultado;
    }
    
    @Override
    public int contar(Predicate<? super T> criterio){
        Objects.requireNonNull(criterio, "El criterio no puede ser nulo");
        int cantidad = 0;
        for (T elemento : elementos){
            if (criterio.test(elemento))
                cantidad++;
        }
        return cantidad;
    }
    
    @Override
    public int actualizar(Predicate<? super T> criterio, Consumer<? super T> accion){
        Objects.requireNonNull(criterio, "El criterio no puede ser nulo");
        Objects.requireNonNull(accion, "La accion no puede ser nula");
        int afectados = 0;
        for (T elemento : elementos){
            if (criterio.test(elemento))
                accion.accept(elemento);
                afectados++;
        }
        return afectados;
    }
    
    @Override
    public int eliminarSi(Predicate<? super T> criterio){
        Objects.requireNonNull(criterio, "El criterio no debe ser nulo");
        int eliminados = 0;
        Iterator<T> it = elementos.iterator();
        while (it.hasNext()){
            T elemento = it.next();
            if (criterio.test(elemento)){
                it.remove();
                eliminados++;
            }
        }
        return eliminados;
    }
    
    @Override
    public void ordenar(){
        Collections.sort(elementos);  
    }
    
    @Override
    public void ordenar(Comparator<? super T> comparador){
        Objects.requireNonNull(comparador, "El comparador no puede ser nulo");
        Collections.sort(elementos, comparador);
    }
    
    @Override
    public <R> List <R> seleccionarYTransformar(Predicate<? super T> criterio, Function<? super T, ? extends R> transformacion){
        Objects.requireNonNull(criterio, "El criterio no puede ser nulo");
        Objects.requireNonNull(transformacion, "La transformacion no puede ser nula");
        List<R> resultado = new ArrayList<>();
        for (T elemento : elementos){
            if (criterio.test(elemento)){
                resultado.add(transformacion.apply(elemento));
            }
        }
        return resultado;
    }
    
    
    public double promediar(Predicate<? super T> criterio, Calculador<? super T> calculador){
        Objects.requireNonNull(criterio, "El criterio no puede ser nulo");
        Objects.requireNonNull(calculador, "El calculador no puede ser nulo");
        double suma = 0;
        int cantidad = 0;
        for (T elemento : elementos){
            if (criterio.test(elemento)){
                suma += calculador.calcular(elemento);
                cantidad++;
            }
        }
        if (cantidad == 0){
            return 0;
        }
        return suma / cantidad;
    }
    
    @Override
    public Iterator<T> iterator(){
        return Collections.unmodifiableList(elementos).iterator();
    }
    
    @Override
    public void guardarBinario(String ruta) throws IOException{
        Objects.requireNonNull(ruta, "La ruta no puede ser nula");
        crearCarpetaPadre(ruta);
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(ruta))){
            salida.writeObject(elementos);
        }
    }
    
    @Override
    public void cargarBinario(String ruta) throws IOException, ClassNotFoundException{
        Objects.requireNonNull(ruta, "La ruta no puede ser nula");
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(ruta))){
            elementos = (List<T>) entrada.readObject();
        }
    }
    
    @Override 
    public void guardarCSV(String ruta, String encabezado) throws IOException{
        Objects.requireNonNull(ruta,"La ruta no puede ser nula");
        Objects.requireNonNull(encabezado, "El encabezado no puede ser nulo");
        crearCarpetaPadre(ruta);
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))){
            escritor.write(encabezado);
            escritor.newLine();
            for (T elemento : elementos){
                escritor.write(elemento.toCSV());
                escritor.newLine();
            }
        }
    }
    
    @Override
    public void cargarCSV(String ruta, Function<String, ? extends T> conversor) throws IOException{
        Objects.requireNonNull(ruta, "La ruta no puede ser nula");
        Objects.requireNonNull(conversor, "el conversor no puede ser nulo");
        List<T> cargados = new ArrayList<>();
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))){
            lector.readLine();
            String linea = lector.readLine();
            while (linea != null){
                if (!linea.isBlank()){
                    agregarEn(cargados, conversor.apply(linea));
                }
                linea = lector.readLine();
            }
        elementos = cargados;
        }
    }
    
    @Override 
    public void exportarReporte(String ruta, String titulo, Predicate<? super T> criterio, Function<? super T, String> formateador) throws IOException{
        Objects.requireNonNull(ruta, "La ruta no puede ser nula");
        Objects.requireNonNull(titulo, "El titulo no puede ser nulo");
        Objects.requireNonNull(criterio, "El criterio no puede ser nulo");
        Objects.requireNonNull(formateador, "El formateador no puede ser nulo");
        crearCarpetaPadre(ruta);
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))){
            escritor.write(titulo);
            escritor.newLine();
            escritor.write("-".repeat(titulo.length()));
            escritor.newLine();
            for (T elemento : elementos){
                if (criterio.test(elemento)){
                    escritor.write(formateador.apply(elemento));
                    escritor.newLine();
                }}}}
    
    private void crearCarpetaPadre(String ruta){
        File carpeta = new File(ruta).getParentFile();
        if (carpeta != null){
            carpeta.mkdirs();
        }
    }
}

